<?php $this->load->view('admin/includes/employer_header'); ?>

    <main>
         <div class="row">
            <div class="col-12">
                <h1>Post Job</h1>
                <div class="separator mb-5"></div>
            </div>
        </div>
        <div class="container-fluid">
           
            <div class="row">
                
                <div class="col-12 col-lg-7 col-xl-8 col-left">
                    <div class="card mb-4">
                        <div class="card-body">

                            <form id="exampleForm" class="tooltip-label-right" novalidate>
                                
                                <label class="form-group has-top-label">
                                    <input class="form-control" name="j_jobTitle" required />
                                    <span>Job Title</span>
                                </label>
                                <label class="form-group has-top-label">
                                    <input class="form-control" name="j_Qualification" />
                                    <span>Qualification</span>
                                </label>
                                <label class="form-group has-top-label">
                                    <input class="form-control" name="j_payScale" />
                                    <span>Pay scale</span>
                                </label>
                                
                                <label class="form-group has-top-label">
                                    <input class="form-control" name="j_skills" />
                                    <span>Skills</span>
                                </label>
                                <div class="form-group">
                                    <label>Job Requirments</label>
                                    <textarea class="form-control" name="j_jobRequirments" id="ckEditorClassic" name="p_address">
                                    </textarea>
                                </div>
                                 <div class="form-group">
                                    <label>Job Description</label>
                                    <textarea class="form-control" name="j_jobDescription" id="ckEditorClassic01" name="p_address">
                                    </textarea>
                                </div>
                               
                                <button class="btn btn-primary" type="submit" name="post">Post</button>
                                <button class="btn btn-outline-primary" type="submit" name="cancel">Cancel</button>
                            
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </main>
    <?php $this->load->view('admin/includes/footer'); ?>